﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SMAManager : MonoBehaviour {

	public SMAAgent[] m_agents;
	public static SMAManager instance = null;

	// Use this for initialization
	void Awake () {
		if(instance == null) {
			instance = this;
			DontDestroyOnLoad (gameObject);
			m_agents = FindObjectsOfType<SMAAgent> ();
		}
		else{
			Destroy (gameObject);
		}
		
	}
	
	// Update is called once per frame
	void Update () {
		foreach (SMAAgent currentAgent in m_agents){
			currentAgent.SMAUpdate (Time.deltaTime);
		}
	}
	
	void FixedUpdate () {
		foreach (SMAAgent currentAgent in m_agents){
			currentAgent.SMAFixedUpdate (Time.fixedDeltaTime);
		}
	}
}
