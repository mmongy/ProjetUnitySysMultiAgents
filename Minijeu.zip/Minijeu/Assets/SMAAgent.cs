﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SMAAgent : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	public virtual void SMAUpdate(float dt){}
	
	public virtual void SMAFixedUpdate(float dt){}
}
