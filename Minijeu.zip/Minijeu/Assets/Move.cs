﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : SMAAgent {
	public PlayerXP m_playerXP;
    public Rigidbody2D playerRigidBody;
    public SpriteRenderer m_renderer;
    public Sprite m_frontSprite;
    public Sprite m_backSprite;
    public Sprite m_sideSprite;
	
	public float m_randomCount = 0.0f;
	private float m_randomMax = 1.0f;

    public float m_speed = 100.0f;
	int valeurAleatoire = 6;

    // Use this for initialization
    void Start () {
		if (m_playerXP.m_status == STATE.ILL) {
			m_speed = 80.0f;
		}
		if (m_playerXP.m_status == STATE.SANE) {
			m_speed = 100.0f;
		}
	}
	
	void immobile(float dt){
		m_renderer.flipX = true;
        m_renderer.sprite = m_sideSprite;
        //gameObject.transform.Translate(new Vector3(-m_speed * Time.deltaTime, 0, 0));
        Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
        prevCoord.x = transform.localPosition.x;
        prevCoord.y = transform.localPosition.y;

        Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
        //newCoord.x = prevCoord.x - m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x;
        newCoord.y = prevCoord.y;

        playerRigidBody.MovePosition(newCoord);
	}
	
	void deplacementGauche(float dt){
		m_renderer.flipX = true;
        m_renderer.sprite = m_sideSprite;
        //gameObject.transform.Translate(new Vector3(-m_speed * Time.deltaTime, 0, 0));
        Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
        prevCoord.x = transform.localPosition.x;
        prevCoord.y = transform.localPosition.y;

        Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
        //newCoord.x = prevCoord.x - m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x - m_speed * dt;
        newCoord.y = prevCoord.y;

        playerRigidBody.MovePosition(newCoord);
	}
	
	void deplacementDroite(float dt){
        m_renderer.flipX = false;
        m_renderer.sprite = m_sideSprite;
		//gameObject.transform.Translate(new Vector3(m_speed * Time.deltaTime, 0, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		//newCoord.x = prevCoord.x + m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x + m_speed * dt;
		newCoord.y = prevCoord.y;

		playerRigidBody.MovePosition(newCoord);		
	}
	
	void deplacementHaut(float dt){
		m_renderer.sprite = m_backSprite;
		//gameObject.transform.Translate(new Vector3(0, m_speed * Time.deltaTime, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		newCoord.x = prevCoord.x;
		//newCoord.y = prevCoord.y + m_speed * Time.fixedDeltaTime;
		newCoord.y = prevCoord.y + m_speed * dt;

		playerRigidBody.MovePosition(newCoord);
	}
	
	void deplacementBas(float dt){
		m_renderer.sprite = m_frontSprite;
		//gameObject.transform.Translate(new Vector3(0, -m_speed * Time.deltaTime, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		newCoord.x = prevCoord.x;
		//newCoord.y = prevCoord.y - m_speed * Time.fixedDeltaTime;
		newCoord.y = prevCoord.y - m_speed * dt;

		playerRigidBody.MovePosition(newCoord);	
	}
	
	void deplacementHautGauche(float dt){
		m_renderer.sprite = m_backSprite;
		//gameObject.transform.Translate(new Vector3(0, m_speed * Time.deltaTime, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		//newCoord.x = prevCoord.x - m_speed * Time.fixedDeltaTime;
		//newCoord.y = prevCoord.y + m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x - m_speed * dt;
		newCoord.y = prevCoord.y + m_speed * dt;

		playerRigidBody.MovePosition(newCoord);		
	}
	
	void deplacementBasGauche(float dt){	
		m_renderer.sprite = m_frontSprite;
		//gameObject.transform.Translate(new Vector3(0, m_speed * Time.deltaTime, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		//newCoord.x = prevCoord.x - m_speed * Time.fixedDeltaTime;
		//newCoord.y = prevCoord.y - m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x - m_speed * dt;
		newCoord.y = prevCoord.y - m_speed * dt;

		playerRigidBody.MovePosition(newCoord);
	}
	
	void deplacementHautDroite(float dt){
		m_renderer.sprite = m_backSprite;
		//gameObject.transform.Translate(new Vector3(0, m_speed * Time.deltaTime, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		//newCoord.x = prevCoord.x + m_speed * Time.fixedDeltaTime;
		//newCoord.y = prevCoord.y + m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x + m_speed * dt;
		newCoord.y = prevCoord.y + m_speed * dt;
		
		playerRigidBody.MovePosition(newCoord);		
	}
	
	void deplacementBasDroite(float dt){
		m_renderer.sprite = m_frontSprite;
		//gameObject.transform.Translate(new Vector3(0, m_speed * Time.deltaTime, 0));
		Vector2 prevCoord = Vector2.zero; // Coordonnées d'origine du joueur
		prevCoord.x = transform.localPosition.x;
		prevCoord.y = transform.localPosition.y;

		Vector2 newCoord = Vector2.zero; // Coordonnées d'arrivée du joueur
		//newCoord.x = prevCoord.x + m_speed * Time.fixedDeltaTime;
		//newCoord.y = prevCoord.y - m_speed * Time.fixedDeltaTime;
		newCoord.x = prevCoord.x + m_speed * dt;
		newCoord.y = prevCoord.y - m_speed * dt;
		
		playerRigidBody.MovePosition(newCoord);		
	}
	
	void Controlled(float dt) {
		playerRigidBody = gameObject.GetComponent<Rigidbody2D>();
        if (Input.GetKey(KeyCode.LeftArrow)){
			deplacementGauche(dt);
        }
       if (Input.GetKey(KeyCode.RightArrow)){
			deplacementDroite(dt);
	   }
        if (Input.GetKey(KeyCode.UpArrow)){
			deplacementHaut(dt);
        }
        if (Input.GetKey(KeyCode.DownArrow)){
			deplacementBas(dt);
        }
		if (Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.UpArrow)){
			deplacementHautGauche(dt);
		}
		if (Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.DownArrow)){
			deplacementBasGauche(dt);
		}
		if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.UpArrow)){
			deplacementHautDroite(dt);
		}
		if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.DownArrow)){
			deplacementBasDroite(dt);
		}
	}
	
	void randomMove(float dt){
		m_randomCount += dt;
		
		if (m_randomCount >= m_randomMax) {
			valeurAleatoire = (int)Random.Range(1f,10f);
			m_randomMax = Random.Range(0.5f, 2.0f);
			m_randomCount = 0.0f;
			Debug.Log(valeurAleatoire);
		}
		
		playerRigidBody = gameObject.GetComponent<Rigidbody2D>();
		
		if(valeurAleatoire == 4){	            
			deplacementGauche(dt);
		}
		if(valeurAleatoire == 6){
			deplacementDroite(dt);
		}
		if(valeurAleatoire == 8){
			deplacementHaut(dt);
		}
		if(valeurAleatoire == 2){
			deplacementBas(dt);
		}
		if (valeurAleatoire == 7){
			deplacementHautGauche(dt);
		}
		if (valeurAleatoire == 1){
			deplacementBasGauche(dt);
		}
		if (valeurAleatoire == 9){
			deplacementHautDroite(dt);
		}
		if (valeurAleatoire == 3){
			deplacementBasDroite(dt);
		}
	}
	
	//void Update (){
	public override void SMAUpdate(float dt){
	
	}
	
	
	// Update is called once per frame
	//void FixedUpdate () {
	public override void SMAFixedUpdate(float dt) {
		if (m_playerXP.m_status == STATE.DEAD) {
			immobile(dt);
		}
		else if(gameObject.tag == "NPC"){
			randomMove(dt);
		}			
		else if(gameObject.tag == "Player"){
			Controlled(dt);
		}
    }
	
	private void OnTriggerEnter2D(Collider2D collision){
		if (collision.gameObject.tag == "DarkGrass"){
			m_speed = 50.0f;
		}
		if (collision.gameObject.tag == "Bush"){
			m_speed = 0.0f;
		}
	}
	
	private void OnTriggerExit2D(Collider2D collision){
		m_speed = 100.0f;
	}
}
